import streamlit as st 
import numpy as np 
import pandas as pd 
from sklearn.ensemble import RandomForestClassifier 
from sklearn.model_selection import train_test_split 
from sklearn.metrics import accuracy_score

data = pd.read_csv('C:/Users/Microsoft/Desktop/Alzheimer/oasis_longitudinal.csv')

# Preprocess the data
X = data[['Age', 'EDUC', 'SES', 'MMSE', 'CDR', 'eTIV', 'nWBV', 'ASF']]
y = data['Group']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

classifier = RandomForestClassifier() 
classifier.fit(X_train, y_train)

def prediction(df): 
    prediction = classifier.predict(df) 
    print(prediction) 
    return prediction


def main():
    st.title("Alzheimer's Diseases Prediction App") 
    

    

    # Main content area
   
    st.title("Guidelines for User:")
    st.write("Range of Features and Information:")
    st.write("1. Age = The Age ranges from 60 to 96.")
    st.write("2. EDUC = Years of Education. Select a value from 6 to 23.")
    st.write("3. SES = Socioeconomic Status. Select a value from 1.0 to 5.0.")
    st.write("4. MMSE = Mini Mental State Examination. Select a value from 17.0 to 30.0.")
    st.write("5. CDR = Clinical Dementia Rating. Select a value from 0 to 1.")
    st.write("6. eTIV = Estimated Total Intracranial Volume. Select a value from 1987 to 1123.")
    st.write("7. nWBV = Normalized Whole Brain Volume. Select a value from 0.66 to 0.837.")
    st.write("8. ASF = Atlas Scaling Factor. Select a value from 0.883 to 1.563.")

        #st.sidebar
    left_column, right_column = st.columns(2)

    Age = left_column.slider('1. Age')
    #st.text("Years of Education for this field you select value from 6 to 23 ")
    EDUC = left_column.number_input('2. EDUC')

    #st.text("SSE ")
    SES = left_column.number_input('3. SES')
    
    #st.text("Mini Mental State Examination")
    MMSE = left_column.number_input('4. MMSE')

    #st.text("CDR")
    CDR = left_column.number_input('5. CDR')

    #st.text("Estimated Total Intracranial Volume")
    eTIV = left_column.number_input('6. eTIV')

    #st.text("Normalized Whole Brain Volume")
    nWBV = left_column.number_input('7. nWBV')

    #st.text("Atlas Scaling Factor")
    ASF = left_column.number_input('8. ASF')

    df = pd.DataFrame(data=[Age, EDUC, SES, MMSE, CDR, eTIV, nWBV, ASF])
    l = np.array([Age, EDUC, SES, MMSE, CDR, eTIV, nWBV, ASF])
    l = l.reshape(1, -1)

    if right_column.button("Predict"):
        result = prediction(l)
        if result == 0:
            o = "Demented"
        else:
            o = "Non-Demented"
        right_column.success('The patient has {}'.format(o))

if __name__ == '__main__':
    main()
