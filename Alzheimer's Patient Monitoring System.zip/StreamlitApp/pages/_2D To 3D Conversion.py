import streamlit as st
import cv2
import numpy as np
from PIL import Image


st.title("2D To 3D Module")



# Load the 2D image
file_up = st.file_uploader("Upload 2D Image", type="jpg")
if file_up is not None:
    img = cv2.imdecode(np.frombuffer(file_up.getvalue(), np.uint8), cv2.IMREAD_COLOR)
    if img is not None:
        img_pil = Image.fromarray(img)  # Convert the NumPy array to a PIL Image object
        st.write("Original 2D Image")
        st.image(img_pil)

        # Convert 2D image to 3D image
        depth = 10  # Set the depth of the 3D image
        height, width, _ = img.shape
        img_3d = np.zeros((depth, height, width, 3), dtype=np.uint8)
        for i in range(depth):
            img_3d[i] = img

        # Convert the 3D NumPy array to a list of PIL Image objects
        img_3d_list = [Image.fromarray(img_3d[i]) for i in range(depth)]

        st.write("3D Image")
        cols = st.columns(4)
        for i in range(depth):
            cols[i % 4].image(img_3d_list[i])
    else:
        st.write("Error: Could not read image file.")
