import streamlit as st
import pandas as pd

st.title("ChatBot")

# Load the dataset
df = pd.read_csv("C:/Users/Microsoft/Desktop/Alzheimer/dataset88.csv")

# Initialize message history
message_history = []

# Function to display messages
def message(message, is_user=False):
    if is_user:
        st.markdown(f"**You:** {message}")
    else:
        st.markdown(f"**Assistant:** {message}")

# Greet the user
st.write("Hello! I'm here to help you with mental health-related questions.")

# User input
user_input = st.text_input("You: ", "")

# Add user input to message history
if user_input:
    message_history.append({"role": "user", "content": user_input})
    message(user_input, is_user=True)

# Check for exit command
if user_input.lower().strip() == "exit":
    st.write("Thank you for using the mental health chatbot. Have a great day!")
    st.stop()

# Display assistant message
if message_history:
    last_message = message_history[-1]
    if last_message["role"] != "assistant":
        # Search the dataset for a matching question
        matching_question = df[df["Questions"] == user_input]
        if not matching_question.empty:
            message(matching_question["Answer"].values[0])
            message_history.append({"role": "assistant", "content": matching_question["Answer"].values[0]})
        else:
            message("I'm sorry, I don't have an answer for that question.")
            message_history.append({"role": "assistant", "content": "I'm sorry, I don't have an answer for that question."})

