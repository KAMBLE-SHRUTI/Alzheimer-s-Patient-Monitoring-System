import streamlit as st

# Set page configuration
st.set_page_config(
    page_title="Multipage App",
    page_icon=" ",
    layout="wide"
)

# Set background image
st.markdown(
    """
    <style>
    body {
        background-image: url("C:/Users/Microsoft/Pictures/Saved Pictures/AlzPrj1.png");
        background-size: cover;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# Title and sidebar
st.title("Wel-Come to the Alzheimer Patient Monitoring system")
st.sidebar.success("Select a page above.")

# Animated GIF
st.image("https://media.giphy.com/media/4Hq2J3sg8LQvL6TX4a/giphy.gif?cid=790b7611vxnocmzad1l0gpmgtrg5dtxmjgrrt7fcu8egjrws&ep=v1_gifs_search&rid=giphy.gif&ct=g", use_column_width=True)

# Animated text with fading effect
st.markdown(
    """
    <style>
    @keyframes fadeIn {
        from {
            opacity: 0;
        }
        to {
            opacity: 1;
        }
    }
    .fade-in {
        animation: fadeIn 2s ease-in-out;
    }
    </style>
    """
    , unsafe_allow_html=True
)

st.markdown('<p class="fade-in" style="color:white; font-size:24px;">This is some animated text with fading effect!</p>', unsafe_allow_html=True)
